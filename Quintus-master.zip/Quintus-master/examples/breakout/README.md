## Breakouts

This is the Quintus implementation of [city41](https://github.com/city41)'s [Breakouts](https://github.com/city41/breakouts) project. It uses MIT licensed art, data and audio assets from that project.# Breakouts -- Quintus


